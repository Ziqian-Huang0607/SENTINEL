"""SENTINEL UI views."""
